
responsive webSite using react jsx and tailwind css

1.npm i
2.npm run dev
happy coding :)
